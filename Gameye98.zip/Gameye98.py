import os, sys
###############
# Dede : Hair #
# Fors : Repo #
###############
try:
 print('')
 print('[0m=====================================================[0;91m')
 os.system('figlet AUTOMATIC')
 print('[0m=====================================================')
 print('[^_*] Penyusun Ilay Tamvan [[0;93mIlay[0m]') 
 print('[^_^] Repo Github Milik Si [[0;93mGameye98[0m]')
 print('''[0m====================================================
 [0;92m[[0m1[0;92m] [0mInstall[0;93m 1337Hash
 [0;92m[[0m2[0;92m] [0mInstall[0;93m Android-Terminal-Emulator
 [0;92m[[0m3[0;92m] [0mInstall[0;93m APAFI
 [0;92m[[0m4[0;92m] [0mInstall[0;93m AstraNmap
 [0;92m[[0m5[0;92m] [0mInstall[0;93m AUXILE
 [0;92m[[0m6[0;92m] [0mInstall[0;93m Auxscan
 [0;92m[[0m7[0;92m] [0mInstall[0;93m Black-Hydra
 [0;92m[[0m8[0;92m] [0mInstall[0;93m DavidWebb
 [0;92m[[0m9[0;92m] [0mInstall[0;93m Eazy
 [0;92m[[0m10[0;92m] [0mInstall[0;93m Ecode
 [0;92m[[0m11[0;92m] [0mInstall[0;93m FaDe
 [0;92m[[0m12[0;92m] [0mInstall[0;93m figlet.js
 [0;92m[[0m13[0;92m] [0mInstall[0;93m Gameye98.github.io
 [0;92m[[0m14[0;92m] [0mInstall[0;93m GINF
 [0;92m[[0m15[0;92m] [0mInstall[0;93m inther
 [0;92m[[0m16[0;92m] [0mInstall[0;93m Katak
 [0;92m[[0m17[0;92m] [0mInstall[0;93m Kawai-Botnet
 [0;92m[[0m18[0;92m] [0mInstall[0;93m Komodo
 [0;92m[[0m19[0;92m] [0mInstall[0;93m Lazymux
 [0;92m[[0m20[0;92m] [0mInstall[0;93m LiteOTP
 [0;92m[[0m21[0;92m] [0mInstall[0;93m mps-youtube
 [0;92m[[0m22[0;92m] [0mInstall[0;93m OSIF
 [0;92m[[0m23[0;92m] [0mInstall[0;93m OWScan
 [0;92m[[0m24[0;92m] [0mInstall[0;93m santet-online
 [0;92m[[0m25[0;92m] [0mInstall[0;93m SpazSMS
 [0;92m[[0m26[0;92m] [0mInstall[0;93m term.js''')
 f=["https://github.com/Gameye98/1337Hash.git", "https://github.com/Gameye98/Android-Terminal-Emulator.git", "https://github.com/Gameye98/APAFI.git", "https://github.com/Gameye98/AstraNmap.git", "https://github.com/Gameye98/AUXILE.git", "https://github.com/Gameye98/Auxscan.git", "https://github.com/Gameye98/Black-Hydra.git", "https://github.com/Gameye98/DavidWebb.git", "https://github.com/Gameye98/Eazy.git", "https://github.com/Gameye98/Ecode.git", "https://github.com/Gameye98/FaDe.git", "https://github.com/Gameye98/figlet.js.git", "https://github.com/Gameye98/Gameye98.github.io.git", "https://github.com/Gameye98/GINF.git", "https://github.com/Gameye98/inther.git", "https://github.com/Gameye98/Katak.git", "https://github.com/Gameye98/Kawai-Botnet.git", "https://github.com/Gameye98/Komodo.git", "https://github.com/Gameye98/Lazymux.git", "https://github.com/Gameye98/LiteOTP.git", "https://github.com/Gameye98/mps-youtube.git", "https://github.com/Gameye98/OSIF.git", "https://github.com/Gameye98/OWScan.git", "https://github.com/Gameye98/santet-online.git", "https://github.com/Gameye98/SpazSMS.git", "https://github.com/Gameye98/term.js.git"]
 print('[0m=====================================================')
 Plh=input('[0;93m[><][0m Install Nomer : ')
 print('=====================================================')
 Y=f[Plh-1]
 if f !=[]:
   try:
     os.system('git clone '+Y)
     print('=====================================================')
     print('[><] Selesai Install (Cek Folder)')
     print('=====================================================')
     os.system('ls')
     print('=====================================================')
   except(ImportError):
     sys.exit()
 else:
   sys.exit()
except(IndexError):
  print('=====================================================')
  print('Nomer > [0;91m['+str(Plh-1)+'[0;91m] [0;93mTidak Ada [0;92m Blaa[0;91mBlaa[0mBlaa..[92m([0;96mCek Ulang[0;96)[0m)')
  print('=====================================================')
  sys.exit()